# mclv-48v-300w-an1017-dspic33ck256mp508 v1.0.0
### Release Highlights
This is the first version of code for sinusoidal hall sensor based control of PMSM on MCLV-48V-300W inverter board with dsPIC33CK256MP508. 
The code is set up for running Hurst075 (AC300020) motor.


### Features Added\Updated



