# X2C Scope library for dsPIC33 DSC
<p style='text-align: justify;'>
X2C-Scope is a virtual oscilloscope tool developed by Linz Center of Mechatronics which allows run-time debugging or monitoring of your embedded application in MPLAB X IDE. This tool allows you to “Watch” or “Plot” any global variable in your embedded application at run-time i.e. without halting your CPU.</p>